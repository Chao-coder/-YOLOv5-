# Letters > 2022-11-15 4:37pm
https://universe.roboflow.com/object-detection/letters-ffs5d

Provided by a Roboflow user
License: CC BY 4.0

